## Setup domain

-- [Register domain](deploy-on-web-domain-registration.md)

-- [Setup domain with DigitalOcean DNS](deploy-on-web-digitalocean.md)

-- [Setup domain with Cloudflare](deploy-on-web-cloudflare.md)
