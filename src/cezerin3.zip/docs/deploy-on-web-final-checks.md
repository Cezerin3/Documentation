## Final checks

That's all.

If you:

1. Run cezerin.
2. Run webserver nginx with cezerin config.
3. Setup DNS records.

You will see working store in your browser by this urls:

Store: https://your-domain-name.com

API: https://your-domain-name.com/api/v1/settings

Dashboard: https://your-domain-name.com/admin
