### Help and Support

### Where to Get Support?

If you're reporting a bug, or you have a feature request, you can use GitHub issues:
https://github.com/cezerin2/cezerin2/issues

If you need some help with deployment and something does not quite work, message on:

- [**Cezerin Community Site**](https://cezerin.org): https://cezerin.org

- [**GitHub Issues**](https://github.com/cezerin2/cezerin2/issues): https://github.com/cezerin2/cezerin2/issues

- [**Telegram Chat: Cezerin**](https://t.me/cezerin): https://t.me/cezerin

- [**Google Groups Forum**](https://groups.google.com/g/cezerin): https://groups.google.com/g/cezerin

### Need Private Support?

https://github.com/vamcart
