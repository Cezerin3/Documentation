Folder must exists
