import React from "react"
import OrderDetails from "modules/orders/edit"

export default OrderDetails
