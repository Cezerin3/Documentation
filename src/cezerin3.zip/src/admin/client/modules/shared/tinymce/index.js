export { default } from "./components/TinyMCE"
