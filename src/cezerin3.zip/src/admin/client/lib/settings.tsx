export default APPLICATION_CONFIG
