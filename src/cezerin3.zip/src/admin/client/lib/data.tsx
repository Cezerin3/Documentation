export default {
  countries: APPLICATION_DATA_COUNTRIES,
  currencies: APPLICATION_DATA_CURRENCIES,
  timezones: APPLICATION_DATA_TIMEZONES
}
