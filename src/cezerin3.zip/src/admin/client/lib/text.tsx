export default APPLICATION_TEXT
